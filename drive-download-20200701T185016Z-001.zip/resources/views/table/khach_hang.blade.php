@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <h4 class="">Danh Sách Khách Hàng</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table tablesorter ">
                        <thead class=" text-primary">
                            <tr>
                                <th>
                                    Mã Khách Hàng
                                </th>
                                <th>
                                    Tên Khách Hàng
                                </th>
                                <th>
                                    Số Điện Thoại
                                </th>
                                <th>
                                    Email
                                </th>
                                <th class="text-center" colspan="2">
                                    <a href="{{route ('admin.them_khach_hang')}}">Thêm Khách Hàng Mới</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($arr_ad as $each)
                            <tr>
                                <td>
                                    {{$each->ma_khach_hang}}
                                </td>
                                <td>
                                    {{$each->ten_khach_hang}}
                                </td>
                                <td>
                                    {{$each->so_dien_thoai}}
                                </td>
                                <td>
                                    {{$each->email}}
                                </td>
                                <td>
                                    <a href="{{ route('admin.sua_thong_tin_khach_hang',[$each->ma_khach_hang])}}"> Sửa</a>
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('admin.xoa_khach_hang',[$each->ma_khach_hang])}}"> Xóa</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection