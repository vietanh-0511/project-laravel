<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\khach_hang_model;

class khach_hang_controller extends Controller
{
    //
    public function them_khach_hang()
    {
        return view('khach_hang/them_khach_hang');
    }
    public function them_khach_hang_xl(Request $them)
    {
        $khach_hang = new khach_hang_model();
        $khach_hang->ma_khach_hang = $them->ma_khach_hang;
        $khach_hang->ten_khach_hang = $them->ten_khach_hang;
        $khach_hang->so_dien_thoai = $them->so_dien_thoai;
        $khach_hang->email = $them->email;
        $khach_hang->them_khach_hang_xl();
        return redirect()->route('admin.ds_khach_hang');
    }
    public function sua_thong_tin_khach_hang($ma_khach_hang)
    {
        $arr_kh = khach_hang_model::get_kh_by_ID($ma_khach_hang);
        return view('khach_hang/sua_thong_tin_khach_hang', compact('arr_kh'));
    }
    public function sua_thong_tin_khach_hang_xl(Request $sua)
    {
        $khach_hang = new khach_hang_model();
        $khach_hang->ma_khach_hang = $sua->ma;
        $khach_hang->ten_khach_hang = $sua->ten_khach_hang;
        $khach_hang->so_dien_thoai = $sua->so_dien_thoai;
        $khach_hang->email = $sua->email;
        $khach_hang->sua_thong_tin_khach_hang_xl();
        return redirect()->route('admin.ds_khach_hang');
    }
    public function xoa_khach_hang($ma_khach_hang)
    {
        $arr_kh = khach_hang_model::delete_kh($ma_khach_hang);
        return redirect()->route('admin.ds_khach_hang');
    }
}
