<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\loai_xe_model;

class loai_xe_controller extends Controller
{
    //
    public function them_loai_xe()
    {
        return view('loai_xe/them_loai_xe');
    }
    public function them_loai_xe_xl(Request $them)
    {
        $loai_xe = new loai_xe_model();
        $loai_xe->ma_loai = $them->ma;
        $loai_xe->loai_xe = $them->loai;
        $loai_xe->so_ghe = $them->so_ghe;
        $loai_xe->them_loai_xe_xl();
        return redirect()->route('admin.ds_loai_xe');
    }
    public function sua_loai_xe($ma_loai)
    {
        $arr_loai = loai_xe_model::get_loai_xe($ma_loai);
        return view('loai_xe/sua_loai_xe', compact('arr_loai'));
    }
    public function sua_loai_xl(Request $sua)
    {
        $loai_xe = new loai_xe_model();
        $loai_xe->ma_loai = $sua->ma;
        $loai_xe->loai_xe = $sua->loai;
        $loai_xe->so_ghe = $sua->so_ghe;
        $loai_xe->sua_loai_xl();
        return redirect()->route('admin.ds_loai_xe');
    }
    public function xoa_loai_xe($ma_loai)
    {
        $loai_xe = new loai_xe_model();
        $loai_xe->xoa_loai_xe($ma_loai);
        return redirect()->route('admin.ds_loai_xe');
    }
}
