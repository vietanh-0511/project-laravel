@extends('layout')
@section('content')
<div class="row">
    @foreach ($arr_ad as $each)
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="title">{{ __('Thông Tin Admin') }}</h5>
            </div>
            <form method="post" action="#" autocomplete="off">

                <div class="card-body">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    @include('alerts.success')

                    <div class="form-group{{ $errors->has('user') ? ' has-danger' : '' }}">
                        <label>{{ __('Tên Đăng Nhập') }}</label>
                        <input type="text" name="user" class="form-control{{ $errors->has('user') ? ' is-invalid' : '' }}" placeholder="{{ __('tên đăng nhập') }}" value="{{$each->ten_dang_nhap}}">
                        @include('alerts.feedback',['field' => 'user'])
                    </div>

                    <div class="form-group{{ $errors->has('pass') ? ' has-danger' : '' }}">
                        <label>{{ __('Mật Khẩu') }}</label>
                        <input type="password" name="pass" class="form-control{{ $errors->has('pass') ? ' is-invalid' : '' }}" placeholder="{{ __('mật khẩu') }}" value="{{$each->mat_khau}}">
                        @include('alerts.feedback',['field' => 'pass'])
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-fill btn-primary">{{ __('Đổi Mật Khẩu') }}</button>
                </div>

            </form>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-user">
            <div class="card-body">
                <p class="card-text">
                    <div class="author">
                        <div class="block block-one"></div>
                        <div class="block block-two"></div>
                        <div class="block block-three"></div>
                        <div class="block block-four"></div>
                        <a href="#">
                            <img class="avatar" src="{{ asset('assets/img/emilyz.jpg') }}" alt="">
                            <h5 class="title">{{$each->ten_dang_nhap}}</h5>
                        </a>
                        <p class="description">
                            {{ __('Ceo/Co-Founder') }}
                        </p>
                    </div>
                </p>
                <div class="card-description">
                    {{ __('Do not be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...') }}
                </div>
            </div>
            <div class="card-footer">
                <div class="button-container">
                    <button class="btn btn-icon btn-round btn-facebook">
                        <i class="fab fa-facebook"></i>
                    </button>
                    <button class="btn btn-icon btn-round btn-twitter">
                        <i class="fab fa-twitter"></i>
                    </button>
                    <button class="btn btn-icon btn-round btn-google">
                        <i class="fab fa-google-plus"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    @endforeach
</div>
@endsection