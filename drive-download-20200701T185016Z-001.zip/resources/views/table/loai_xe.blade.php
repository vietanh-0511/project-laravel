@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <h4 class="">Loại Xe</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table tablesorter " id="">
                        <thead class=" text-primary">
                            <tr>
                                <th>
                                    Mã
                                </th>
                                <th>
                                    Loại Xe
                                </th>
                                <th>
                                    Số Ghế
                                </th>
                                <th class="text-center" colspan="2">
                                    <a href="{{route ('admin.them_loai_xe')}}">Thêm loại xe mới</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($arr_ad as $each)
                            <tr>
                                <td>
                                    {{$each->ma_loai}}
                                </td>
                                <td>
                                    {{$each->loai_xe}}
                                </td>
                                <td>
                                    {{$each->so_ghe}}
                                </td>
                                <td>
                                    <a href="{{ route('admin.sua_loai_xe',[$each->ma_loai])}}"> Sửa</a>
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('admin.xoa_loai_xe',[$each->ma_loai])}}"> Xóa</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection