<?php

namespace App\Http\Controllers;

use App\admin_model;
use Illuminate\Http\Request;

class admin_controller extends Controller
{
    //
    public function login()
    {
        return view('login');
    }
    public function login_process(Request $rq)
    {
        $user = $rq->user;
        $pass = $rq->pass;
        $arr_login = admin_model::login_process($user, $pass);
        
        if (count($arr_login) == 1) {
            $rq->session()->put('ma', $arr_login[0]->ma_admin);
            return redirect()->route('admin.admin');
        } else {
            return redirect()->route('login')->with('success', 'lỗi');
        }
    }
    public function logout(Request $rq)
    {
        $rq->session()->flush();
        return redirect()->route('login');
    }
    public function admin()
    {
        $arr_ad = admin_model::get_admin();
        return view('table/admin', compact('arr_ad'));
    }
    public function ds_hang_xe()
    {
        $arr_ad = admin_model::ds_hang_xe();
        return view('table/hang_xe', compact('arr_ad'));
    }
    public function ds_loai_xe()
    {
        $arr_ad = admin_model::ds_loai_xe();
        return view('table/loai_xe', compact('arr_ad'));
    }

    public function ds_tuyen_xe_chay()
    {
        $arr_ad = admin_model::ds_tuyen_xe_chay();
        return view('table/tuyen_duong', compact('arr_ad'));
    }
    public function ds_khach_hang()
    {
        $arr_ad = admin_model::ds_khach_hang();
        return view('table/khach_hang', compact('arr_ad'));
    }
}
