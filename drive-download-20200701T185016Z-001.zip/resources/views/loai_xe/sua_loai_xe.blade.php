
@extends('layout')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="title">{{ __('Sửa Loại Xe') }}</h5>
            </div>
            <form method="post" action="{{ route('admin.sua_loai_xl') }}" autocomplete="off">
                @foreach ($arr_loai as $each)
                <div class="card-body">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    @include('alerts.success')

                    <div class="form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
                        <label>{{ __('Mã:') }}</label>
                        <input type="number" name="ma" class="form-control{{ $errors->has('ma') ? ' is-invalid' : '' }}" value="{{$each->ma_loai}}" readonly>
                        @include('alerts.feedback', ['field' => 'ma'])
                    </div>

                    <div class="form-group{{ $errors->has('hang') ? ' has-danger' : '' }}">
                        <label>{{ __('Loại Xe') }}</label>
                        <input type="text" name="loai" class="form-control{{ $errors->has('loai_xe') ? ' is-invalid' : '' }}" value="{{$each->loai_xe}}" required>
                        @include('alerts.feedback', ['field' => 'loai_xe'])
                    </div>

                    <div class="form-group{{ $errors->has('hang') ? ' has-danger' : '' }}">
                        <label>{{ __('Số Ghế') }}</label>
                        <input type="text" name="so_ghe" class="form-control{{ $errors->has('so_ghe') ? ' is-invalid' : '' }}" value="{{$each->so_ghe}}" required>
                        @include('alerts.feedback', ['field' => 'so_ghe'])
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-fill btn-primary">{{ __('Lưu Thay Đổi') }}</button>
                </div>
            </form>
            @endforeach
        </div>

    </div>

</div>
@endsection