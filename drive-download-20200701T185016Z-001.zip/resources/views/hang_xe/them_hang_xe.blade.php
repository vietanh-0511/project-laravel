
@extends('layout')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="title">{{ __('Thêm Hãng Xe') }}</h5>
            </div>
            <form method="post" action="{{ route('admin.them_hang_xe_xl') }}" autocomplete="off">
                <div class="card-body">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    @include('alerts.success')


                    <div class="form-group{{ $errors->has('hang') ? ' has-danger' : '' }}">
                        <label>{{ __('Tên Hãng') }}</label>
                        <input type="text" name="hang" class="form-control{{ $errors->has('hang') ? ' is-invalid' : '' }}" placeholder="Tên Hãng Xe" required>
                        @include('alerts.feedback', ['field' => 'hang'])
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-fill btn-primary">{{ __('Thêm') }}</button>
                </div>
            </form>
        </div>

    </div>

</div>
@endsection