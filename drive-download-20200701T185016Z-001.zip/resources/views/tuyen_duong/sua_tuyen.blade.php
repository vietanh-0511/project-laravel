@extends('layout')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="title">{{ __('Sửa') }}</h5>
            </div>
            <form method="post" action="{{ route('admin.sua_tuyen_duong_xl') }}" autocomplete="off">
                @foreach ($arr_tuyenduong as $each)
                <div class="card-body">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    @include('alerts.success')
                    <div class="form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
                        <label>{{ __('Mã:') }}</label>
                        <input type="hidden" name="ma" class="form-control{{ $errors->has('ma') ? ' is-invalid' : '' }}" value="{{$each->ma_tuyen}}" readonly>
                        @include('alerts.feedback', ['field' => 'ma'])
                    </div>

                    <div class="form-group{{ $errors->has('tuyen_duong') ? ' has-danger' : '' }}">
                        <label>{{ __('Tuyến Đường') }}</label>
                        <input type="text" name="tuyen_duong" class="form-control{{ $errors->has('tuyen_duong') ? ' is-invalid' : '' }}" placeholder="Tuyến Đường" value="{{$each->tuyen_duong}}" required>
                        @include('alerts.feedback', ['field' => 'tuyen_duong'])
                    </div>

                    <div class=" form-group{{ $errors->has('diem_di') ? ' has-danger' : '' }}">
                        <label>{{ __('Điểm Đi') }}</label>
                        <input type="text" name="diem_di" class="form-control{{ $errors->has('diem_di') ? ' is-invalid' : '' }}" placeholder="Điểm Đi" value="{{$each->diem_di}}" required>
                        @include('alerts.feedback', ['field' => 'diem_di'])
                    </div>

                    <div class=" form-group{{ $errors->has('diem_den') ? ' has-danger' : '' }}">
                        <label>{{ __('Điểm Đến') }}</label>
                        <input type="text" name="diem_den" class="form-control{{ $errors->has('diem_den') ? ' is-invalid' : '' }}" placeholder="Điểm Đến" value="{{$each->diem_den}}" required>
                        @include('alerts.feedback', ['field' => 'diem_den'])
                    </div>
                </div>
                <div class=" card-footer">
                    <button type="submit" class="btn btn-fill btn-primary">{{ __('Lưu Thay Đổi') }}</button>
                </div>
            </form>
            @endforeach
        </div>

    </div>

</div>
@endsection