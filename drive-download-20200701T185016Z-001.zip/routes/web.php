<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\admin_controller;

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('login', 'admin_controller@login')->name('login');
Route::post('login', 'admin_controller@login_process')->name('login_process');
Route::get('logout', 'admin_controller@logout')->name('logout');

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'middleware' => ['admin_middleware']], function () {
    Route::get('admin', 'admin_controller@admin')->name('admin');
    Route::get('ds_hang_xe', 'admin_controller@ds_hang_xe')->name('ds_hang_xe');
    Route::get('them_hang_xe', 'hang_xe_controller@them_hang_xe')->name('them_hang_xe');
    Route::post('them_hang_xe_xl', 'hang_xe_controller@them_hang_xe_xl')->name('them_hang_xe_xl');
    Route::get('sua_hang_xe/{ma_hang}', 'hang_xe_controller@sua_hang_xe')->name('sua_hang_xe');
    Route::post('sua_hang_xe', 'hang_xe_controller@sua_hx_xl')->name('sua_hx_xl');
    Route::get('xoa_hang_xe/{ma_hang}', 'hang_xe_controller@xoa_hang_xe')->name('xoa_hang_xe');

    Route::get('ds_loai_xe', 'admin_controller@ds_loai_xe')->name('ds_loai_xe');
    Route::get('them_loai_xe', 'loai_xe_controller@them_loai_xe')->name('them_loai_xe');
    Route::post('them_loai_xe_xl', 'loai_xe_controller@them_loai_xe_xl')->name('them_loai_xe_xl');
    Route::get('sua_loai_xe/{ma_loai}', 'loai_xe_controller@sua_loai_xe')->name('sua_loai_xe');
    Route::post('sua_loai_xe', 'loai_xe_controller@sua_loai_xl')->name('sua_loai_xl');
    Route::get('xoa_loai_xe/{ma_loai}', 'loai_xe_controller@xoa_loai_xe')->name('xoa_loai_xe');

    Route::get('ds_tuyen_xe_chay', 'admin_controller@ds_tuyen_xe_chay')->name('ds_tuyen_xe_chay');
    Route::get('them_tuyen', 'tuyen_duong_controller@them_tuyen')->name('them_tuyen');
    Route::post('them_tuyen_xl', 'tuyen_duong_controller@them_tuyen_xl')->name('them_tuyen_xl');
    Route::get('sua_tuyen_duong/{ma_tuyen}', 'tuyen_duong_controller@sua_tuyen_duong')->name('sua_tuyen_duong');
    Route::post('sua_tuyen_duong', 'tuyen_duong_controller@sua_tuyen_duong_xl')->name('sua_tuyen_duong_xl');
    Route::get('xoa_tuyen_duong/{ma_tuyen}', 'tuyen_duong_controller@xoa_tuyen_duong')->name('xoa_tuyen_duong');

    Route::get('ds_khach_hang', 'admin_controller@ds_khach_hang')->name('ds_khach_hang');
    Route::get('them_khach_hang', 'khach_hang_controller@them_khach_hang')->name('them_khach_hang');
    Route::post('them_khach_hang_xl', 'khach_hang_controller@them_khach_hang_xl')->name('them_khach_hang_xl');
    Route::get('sua_thong_tin_khach_hang/{ma_khach_hang}', 'khach_hang_controller@sua_thong_tin_khach_hang')->name('sua_thong_tin_khach_hang');
    Route::post('sua_thong_tin_khach_hang', 'khach_hang_controller@sua_thong_tin_khach_hang_xl')->name('sua_thong_tin_khach_hang_xl');
    Route::get('xoa_khach_hang/{ma_khach_hang}', 'khach_hang_controller@xoa_khach_hang')->name('xoa_khach_hang');
   
    Route::post('layout', 'admin_controller@layout')->name('layout');
});
