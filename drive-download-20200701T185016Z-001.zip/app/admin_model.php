<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class admin_model extends Model
{
    //
    public $ma_admin;
    public $ten_dang_nhap;
    public $mat_khau;
    static function login_process($user, $pass)
    {
        $arr_login = DB::select("select * from admin where ten_dang_nhap=? and mat_khau=?", [
            $user,
            $pass
        ]);
        return $arr_login;
    }
    static function get_admin()
    {
        $result = DB::select("select * from admin");
        return $result;
    }
    static function ds_hang_xe()
    {
        $result = DB::select("select * from hang_xe");
        return $result;
    }
    static function ds_loai_xe()
    {
        $result = DB::select("select * from loai_xe");
        return $result;
    }
    static function ds_tuyen_xe_chay()
    {
        $result = DB::select("select * from tuyen_duong");
        return $result;
    }
    static function ds_khach_hang()
    {
        $result = DB::select("select * from khach_hang");
        return $result;
    }
}
