@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <h4 class="">Tuyến Xe Chạy</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table tablesorter " id="">
                        <thead class=" text-primary">
                            <tr>
                                <th>
                                    Tuyến Xe Chạy
                                </th>
                                <th>
                                    Điểm Đi
                                </th>
                                <th>
                                    Điểm Đến
                                </th>
                                <th class="text-center" colspan="2">
                                    <a href="{{route ('admin.them_tuyen')}}">Thêm Tuyến Đường Mới</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($arr_ad as $each)
                            <tr>
                                <td>
                                    {{$each->tuyen_duong}}
                                </td>
                                <td>
                                    {{$each->diem_di}}
                                </td>
                                <td>
                                    {{$each->diem_den}}
                                </td>
                                <td>
                                    <a href="{{ route('admin.sua_tuyen_duong',[$each->ma_tuyen])}}"> Sửa</a>
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('admin.xoa_tuyen_duong',[$each->ma_tuyen])}}"> Xóa</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection