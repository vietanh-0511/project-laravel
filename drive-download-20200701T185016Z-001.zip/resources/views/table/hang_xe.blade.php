@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <h4 class="card-title">Hãng xe</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table tablesorter " id="">
                        <thead class=" text-primary">
                            <tr>
                                <th>
                                    Mã
                                </th>
                                <th>
                                    Hãng Xe
                                </th>
                                <th class="text-center" colspan="2">
                                    <a href="{{route ('admin.them_hang_xe')}}">Thêm hãng xe mới</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($arr_ad as $each)
                            <tr>
                                <td>
                                    {{$each->ma_hang}}
                                </td>
                                <td>
                                    {{$each-> ten_hang}}
                                </td>
                                <td>
                                    <a href="{{ route('admin.sua_hang_xe',[$each->ma_hang])}}"> Sửa</a>
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('admin.xoa_hang_xe',[$each->ma_hang])}}"> Xóa</a>
                                </td>
                            </tr>

                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection