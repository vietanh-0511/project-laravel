<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class khach_hang_model extends Model    
{
    //
    public $ma_khach_hang;
    public $ten_khach_hang;
    public $so_dien_thoai;
    public $email;
    
    public function them_khach_hang_xl()
    {
        DB::insert("insert into khach_hang(ten_khach_hang,so_dien_thoai,email) values (?,?,?)", [
            $this->ten_khach_hang,
            $this->so_dien_thoai,
            $this->email
        ]);
    }
    static function get_kh_by_ID($ma_khach_hang)
    {
        $sql = "select * from khach_hang where ma_khach_hang ='$ma_khach_hang'";
        $result = DB::select($sql);
        return $result;
    }
    public function sua_thong_tin_khach_hang_xl()
    {
        DB::update("update khach_hang set ten_khach_hang = ?, so_dien_thoai = ?, email = ? where ma_khach_hang= ?", [
            $this->ten_khach_hang,
            $this->so_dien_thoai,
            $this->email,
            $this->ma_khach_hang
        ]);
    }
    public static function delete_kh($ma_khach_hang)
    {
        $sql = "delete from khach_hang where ma_khach_hang = '$ma_khach_hang'";
        DB::delete($sql);
    }
}
