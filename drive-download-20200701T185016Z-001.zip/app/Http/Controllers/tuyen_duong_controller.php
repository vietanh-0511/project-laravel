<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tuyen_duong_model;

class tuyen_duong_controller extends Controller
{
    //
    public function them_tuyen()
    {
        return view('tuyen_duong/them_tuyen');
    }
    public function them_tuyen_xl(Request $them)
    {
        $tuyen_duong = new tuyen_duong_model();
        $tuyen_duong->ma_tuyen = $them->ma_tuyen;
        $tuyen_duong->tuyen_duong = $them->tuyen_duong;
        $tuyen_duong->diem_di = $them->diem_di;
        $tuyen_duong->diem_den = $them->diem_den;
        $tuyen_duong->them_tuyen_xl();
        return redirect()->route('admin.ds_tuyen_xe_chay');
    }
    public function sua_tuyen_duong($ma_tuyen)
    {
        $arr_tuyenduong = tuyen_duong_model::get_tuyenduong_by_ID($ma_tuyen);
        return view('tuyen_duong/sua_tuyen', compact('arr_tuyenduong'));
    }
    public function sua_tuyen_duong_xl(Request $sua)
    {
        $tuyen_duong = new tuyen_duong_model();
        $tuyen_duong->ma_tuyen = $sua->ma;
        $tuyen_duong->tuyen_duong = $sua->tuyen_duong;
        $tuyen_duong->diem_di = $sua->diem_di;
        $tuyen_duong->diem_den = $sua->diem_den;
        $tuyen_duong->sua_tuyen_duong_xl();
        return redirect()->route('admin.ds_tuyen_xe_chay');
    }
    public function xoa_tuyen_duong($ma_tuyen)
    {
        $arr_tuyenduong = tuyen_duong_model::xoa_tuyen_duong($ma_tuyen);
        return redirect()->route('admin.ds_tuyen_xe_chay');
    }
}
