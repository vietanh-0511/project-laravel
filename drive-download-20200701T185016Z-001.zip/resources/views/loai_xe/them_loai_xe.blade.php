

@extends('layout')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="title">{{ __('Thêm Loại Xe') }}</h5>
            </div>
            <form method="post" action="{{ route('admin.them_loai_xe_xl') }}" autocomplete="off">
                <div class="card-body">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    @include('alerts.success')

                    <div class="form-group{{ $errors->has('loai') ? ' has-danger' : '' }}">
                        <label>{{ __('Loại Xe') }}</label>
                        <input type="text" name="loai" class="form-control{{ $errors->has('loai') ? ' is-invalid' : '' }}" placeholder="Loại Xe" required>
                        @include('alerts.feedback', ['field' => 'loai'])
                    </div>

                    <div class="form-group{{ $errors->has('so_ghe') ? ' has-danger' : '' }}">
                        <label>{{ __('Số Ghế') }}</label>
                        <input type="number" name="so_ghe" class="form-control{{ $errors->has('so_ghe') ? ' is-invalid' : '' }}" placeholder="Số  Ghế" required>
                        @include('alerts.feedback', ['field' => 'so_ghe'])
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-fill btn-primary">{{ __('Thêm') }}</button>
                </div>
            </form>
        </div>

    </div>

</div>
@endsection