@extends('layout')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="title">{{ __('Sửa') }}</h5>
            </div>
            <form method="post" action="{{ route('admin.sua_thong_tin_khach_hang_xl') }}" autocomplete="off">
                @foreach ($arr_kh as $each)
                <div class="card-body">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    @include('alerts.success')
                    <div class="form-group{{ $errors->has('ma') ? ' has-danger' : '' }}">
                        <label>{{ __('Mã:') }}</label>
                        <input type="hidden" name="ma" class="form-control{{ $errors->has('ma') ? ' is-invalid' : '' }}" value="{{$each->ma_khach_hang}}" readonly>
                        @include('alerts.feedback', ['field' => 'ma'])
                    </div>

                    <div class="form-group{{ $errors->has('ten_khach_hang') ? ' has-danger' : '' }}">
                        <label>{{ __('Tên Khách Hàng') }}</label>
                        <input type="text" name="ten_khach_hang" class="form-control{{ $errors->has('ten_khach_hang') ? ' is-invalid' : '' }}" placeholder="Nhập Tên" value="{{$each->ten_khach_hang}}" required>
                        @include('alerts.feedback', ['field' => 'ten_khach_hang'])
                    </div>

                    <div class="form-group{{ $errors->has('so_dien_thoai') ? ' has-danger' : '' }}">
                        <label>{{ __('Số Điện Thoại') }}</label>
                        <input type="text" name="so_dien_thoai" class="form-control{{ $errors->has('so_dien_thoai') ? ' is-invalid' : '' }}" placeholder="Nhập Số Điện Thoại" value="{{$each->so_dien_thoai}}" required>
                        @include('alerts.feedback', ['field' => 'so_dien_thoai'])
                    </div>

                    <div class="form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
                        <label>{{ __('Email') }}</label>
                        <input type="email" name="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" placeholder="Nhập Email" value="{{$each->email}}" required>
                        @include('alerts.feedback', ['field' => 'email'])
                    </div>
                </div>
                <div class=" card-footer">
                    <button type="submit" class="btn btn-fill btn-primary">{{ __('Lưu Thay Đổi') }}</button>
                </div>
            </form>
            @endforeach
        </div>

    </div>

</div>
@endsection